import os
import cv2
import pytesseract
from PIL import Image
from reportlab.pdfgen import canvas
import yolov5

# Path to Tesseract executable
pytesseract.pytesseract.tesseract_cmd = r"C:\Users\RyaanBansal\AppData\Local\Programs\Tesseract-OCR\tesseract.exe"

# Load YOLOv5 license plate detection model
model = yolov5.load('keremberke/yolov5m-license-plate')
model.conf = 0.2  # Confidence threshold

# Folder containing images
folder_path = "Sample set"
image_files = [f for f in os.listdir(folder_path) if f.endswith((".png", ".jpg", ".jpeg"))]

# Function to detect and extract license plate text
def extract_license_plate_text_yolo(image_path):
    results = model(image_path)
    detections = results.xyxy[0]  # Bounding boxes

    img = cv2.imread(image_path)
    texts = []

    for *box, conf, cls in detections:
        x1, y1, x2, y2 = map(int, box)
        roi = img[y1:y2, x1:x2]
        gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
        text = pytesseract.image_to_string(gray, config='--psm 8').strip()
        if text:
            texts.append(text)
    
    return texts if texts else ["License plate not found"]

# Save extracted texts to PDF
def save_texts_to_pdf(texts, output_pdf):
    c = canvas.Canvas(output_pdf)
    y_position = 750
    for i, text in enumerate(texts):
        c.drawString(100, y_position, f"Image {i+1}: {text}")
        y_position -= 30
    c.save()

# Process all images
all_texts = []
for file in image_files:
    img_path = os.path.join(folder_path, file)
    texts = extract_license_plate_text_yolo(img_path)
    all_texts.append(", ".join(texts))

# Save results
save_texts_to_pdf(all_texts, "License_Plates.pdf")
print("Extracted texts saved to License_Plates.pdf")
