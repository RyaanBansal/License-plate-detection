import cv2
import pytesseract
from PIL import Image
from reportlab.pdfgen import canvas
import os

# Path to Tesseract executable
pytesseract.pytesseract.tesseract_cmd = r"C:\Users\RyaanBansal\AppData\Local\Programs\Tesseract-OCR\tesseract.exe"

# Load Indian license plate Haar cascade
plate_cascade = cv2.CascadeClassifier('indian_license_plate.xml')  # Ensure this file is in your working directory

# Folder containing images
folder_path = "Sample set"
image_files = [f for f in os.listdir(folder_path) if f.endswith((".png", ".jpg", ".jpeg"))]

# Function to detect and extract license plate text
def extract_license_plate_text(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    plates = plate_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=4)

    for (x, y, w, h) in plates:
        roi = gray[y:y + h, x:x + w]
        text = pytesseract.image_to_string(roi, config='--psm 8').strip()
        if text:
            return text
    return "License plate not found"

# Function to save extracted texts to PDF
def save_texts_to_pdf(texts, output_pdf):
    c = canvas.Canvas(output_pdf)
    y_position = 750
    for i, text in enumerate(texts):
        c.drawString(100, y_position, f"Image {i+1}: {text}")
        y_position -= 30
    c.save()

# Process all images
extracted_texts = []
for file in image_files:
    img_path = os.path.join(folder_path, file)
    img = cv2.imread(img_path)
    if img is not None:
        text = extract_license_plate_text(img)
        extracted_texts.append(text)

# Save results
save_texts_to_pdf(extracted_texts, "License_Plates.pdf")
print("Extracted texts saved to License_Plates.pdf")
