from langchain.document_loaders import PyPDFDirectoryLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import AzureOpenAIEmbeddings
from langchain.vectorstores import Chroma
from langchain.chat_models import AzureChatOpenAI
import os

# Set Azure environment variables
os.environ["AZURE_OPENAI_API_KEY"] = "your-azure-api-key"
os.environ["AZURE_OPENAI_ENDPOINT"] = "https://your-resource-name.openai.azure.com/"
os.environ["AZURE_OPENAI_API_VERSION"] = "2024-02-15-preview"  # or latest supported

def rag_pipeline(query):
    # 1. Load Documents
    loader = PyPDFDirectoryLoader("License_Plates.pdf")
    documents = loader.load()

    # 2. Split Text
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    chunks = text_splitter.split_documents(documents)

    # 3. Embeddings (Azure OpenAI)
    embeddings = AzureOpenAIEmbeddings(
        deployment="your-embedding-deployment-name",  # e.g., "text-embedding-ada-002"
        model="text-embedding-ada-002"
    )

    # 4. Vector Store
    vectorstore = Chroma.from_documents(chunks, embeddings)

    # 5. Retrieval
    retriever = vectorstore.as_retriever()
    retrieved_docs = retriever.get_relevant_documents(query)

    # 6. Generation using Azure Chat Model
    llm = AzureChatOpenAI(
        deployment_name="your-chat-deployment-name",  # e.g., "gpt-35-turbo"
        model_name="gpt-35-turbo"
    )
    context = "\n".join([doc.page_content for doc in retrieved_docs])
    prompt = f"Context: {context}\nQuestion: {query}"
    answer = llm.invoke(prompt)

    return answer

# Example usage
question = "What is the car number starting with KL?"
answer = rag_pipeline(question)
print(f"Question: {question}\nAnswer: {answer}")
