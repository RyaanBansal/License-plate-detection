import yolov5  # pip install yolov5
import cv2
import numpy as np  # pip install numpy
import easyocr  # pip install easyocr
from PIL import Image
import os
from reportlab.pdfgen import canvas

# 📂 Folder paths
image_folder = "car number plates\images"
output_folder = "Cropped_plates"
pdf_output_path = "License_Plates.pdf"

# 🧠 Load YOLOv5 model from Hugging Face
model = yolov5.load('keremberke/yolov5m-license-plate')

# 🔍 Initialize EasyOCR reader
reader = easyocr.Reader(['en'])

# 📂 Create output folder
os.makedirs(output_folder, exist_ok=True)

# 📃 To store filename + list of texts
results_list = []

# --- Configuration for Dynamic Resizing ---
MIN_DIM_THRESHOLD = 70
TARGET_SHORT_DIM_FOR_SMALL_PLATES = 120
DEFAULT_LARGE_PLATE_SCALE_FACTOR = 1.0
# --- End Configuration ---

# 🌈 Loop through each image
for filename in os.listdir(image_folder):
    if filename.lower().endswith((".jpg", ".jpeg", ".png")):
        image_path = os.path.join(image_folder, filename)
        image = cv2.imread(image_path)
        if image is None:
            print(f"❌ Could not read {filename}")
            continue

        results = model(image)
        predictions = results.pred[0]
        detected_texts = []

        for idx, box in enumerate(predictions):
            x1, y1, x2, y2 = map(int, box[:4])
            cropped = image[y1:y2, x1:x2]

            h, w = cropped.shape[:2]
            short_dim = min(h, w)

            if short_dim < MIN_DIM_THRESHOLD:
                scale_factor = TARGET_SHORT_DIM_FOR_SMALL_PLATES / short_dim
                print(f" Scaling small plate (dim: {short_dim}px) with factor: {scale_factor:.2f}")
            else:
                scale_factor = DEFAULT_LARGE_PLATE_SCALE_FACTOR
                print(f" Keeping decent-sized plate (dim: {short_dim}px) with factor: {scale_factor:.2f}")

            scale_factor = max(1.0, scale_factor)
            dim = (int(w * scale_factor), int(h * scale_factor))
            resized_plate = cv2.resize(cropped, dim, interpolation=cv2.INTER_CUBIC)

            sharpening_kernel = np.array([[-1, -1, -1],
                                          [-1, 9, -1],
                                          [-1, -1, -1]])
            sharpened_plate = cv2.filter2D(resized_plate, -1, sharpening_kernel)

            alpha = 1.2
            beta = 5
            adjusted_plate = cv2.convertScaleAbs(sharpened_plate, alpha=alpha, beta=beta)

            enhanced_image_for_ocr = adjusted_plate

            cropped_path = os.path.join(output_folder, f"{os.path.splitext(filename)[0]}_plate_{idx+1}.jpg")
            cv2.imwrite(cropped_path, enhanced_image_for_ocr)

            ocr_result = reader.readtext(enhanced_image_for_ocr)
            if ocr_result:
                texts = [item[1].strip() for item in ocr_result]
                detected_texts.append(" ".join(texts))
            else:
                detected_texts.append("OCR failed")

        if not detected_texts:
            detected_texts.append("Plate not detected")

        results_list.append((filename, detected_texts))

# 📝 Save to PDF
def save_to_pdf(results, pdf_path):
    c = canvas.Canvas(pdf_path)
    y_position = 770
    c.setFont("Helvetica-Bold", 14)
    c.drawString(100, y_position, "License Plate Detection Results")
    y_position -= 15
    c.line(100, y_position, 500, y_position)
    y_position -= 30
    c.setFont("Helvetica", 10)

    for i, (fname, texts) in enumerate(results):
        for j, text in enumerate(texts):
            image_name = os.path.splitext(fname)[0]
            c.drawString(100, y_position, f"{image_name} - Plate {j+1}: {text}")
            y_position -= 15
            if y_position < 50:
                c.showPage()
                y_position = 770
                c.setFont("Helvetica-Bold", 14)
                c.drawString(100, y_position, "License Plate Detection Results (Continued)")
                y_position -= 15
                c.line(100, y_position, 500, y_position)
                y_position -= 30
                c.setFont("Helvetica", 10)

    c.save()

save_to_pdf(results_list, pdf_output_path)
print(f"\n📄 Results saved to: {pdf_output_path}")
