import cv2
import pytesseract
from PIL import Image
from reportlab.pdfgen import canvas
import os

pytesseract.pytesseract.tesseract_cmd = r"C:\Users\RyaanBansal\AppData\Local\Programs\Tesseract-OCR\tesseract.exe"

# Load the uploaded image
image = cv2.imread('Cars0.png')  # Replace with the actual path to the uploaded image

# Convert to grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply preprocessing
gray = cv2.bilateralFilter(gray, 11, 17, 17)
edged = cv2.Canny(gray, 30, 200)

# Find contours
contours, _ = cv2.findContours(edged.copy(), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
contours = sorted(contours, key=cv2.contourArea, reverse=True)[:10]

# Try to find the license plate contour
for contour in contours:
    peri = cv2.arcLength(contour, True)
    approx = cv2.approxPolyDP(contour, 0.018 * peri, True)
    if len(approx) == 4:
        x, y, w, h = cv2.boundingRect(contour)
        roi = gray[y:y + h, x:x + w]
        break

# OCR on the region of interest
text = pytesseract.image_to_string(roi, config='--psm 8')
print("Extracted License Plate Number:", text.strip())

def save_text_to_pdf(text, output_pdf):
    c = canvas.Canvas(output_pdf)
    c.drawString(100, 750, text)  # Adjust position as needed
    c.save()

save_text_to_pdf(text.strip(), "Number plate.pdf")
