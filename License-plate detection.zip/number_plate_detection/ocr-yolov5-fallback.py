import os
import cv2
import pytesseract
from PIL import Image
from reportlab.pdfgen import canvas
import yolov5

# Path to Tesseract executable
pytesseract.pytesseract.tesseract_cmd = r"C:\Users\RyaanBansal\AppData\Local\Programs\Tesseract-OCR\tesseract.exe"

# Load YOLOv5 license plate detection model
model = yolov5.load('keremberke/yolov5m-license-plate')
model.conf = 0.2  # Confidence threshold

# Folder containing images
folder_path = "Sample set"
image_files = [f for f in os.listdir(folder_path) if f.endswith((".png", ".jpg", ".jpeg"))]

# Fallback method using contour detection
def extract_license_plate_text_contour(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    gray = cv2.bilateralFilter(gray, 11, 17, 17)
    edged = cv2.Canny(gray, 30, 200)
    contours, _ = cv2.findContours(edged.copy(), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    contours = sorted(contours, key=cv2.contourArea, reverse=True)[:10]

    for contour in contours:
        peri = cv2.arcLength(contour, True)
        approx = cv2.approxPolyDP(contour, 0.018 * peri, True)
        if len(approx) == 4:
            x, y, w, h = cv2.boundingRect(contour)
            roi = gray[y:y + h, x:x + w]
            text = pytesseract.image_to_string(roi, config='--psm 8').strip()
            if text:
                return text
    return "License plate not found"

# Combined detection function
def extract_license_plate_text(image_path):
    results = model(image_path)
    detections = results.xyxy[0]

    img = cv2.imread(image_path)
    texts = []

    if len(detections) > 0:
        for *box, conf, cls in detections:
            x1, y1, x2, y2 = map(int, box)
            roi = img[y1:y2, x1:x2]
            gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
            text = pytesseract.image_to_string(gray, config='--psm 8').strip()
            if text:
                texts.append(text)
    else:
        # Fallback to contour-based method
        text = extract_license_plate_text_contour(img)
        texts.append(text)

    return texts

# Save extracted texts to PDF
def save_texts_to_pdf(texts, output_pdf):
    c = canvas.Canvas(output_pdf)
    y_position = 750
    for i, text in enumerate(texts):
        c.drawString(100, y_position, f"Image {i+1}: {text}")
        y_position -= 30
    c.save()

# Process all images
all_texts = []
for file in image_files:
    img_path = os.path.join(folder_path, file)
    texts = extract_license_plate_text(img_path)
    all_texts.append(", ".join(texts))

# Save results
save_texts_to_pdf(all_texts, "License_Plates.pdf")
print("Extracted texts saved to License_Plates.pdf")
