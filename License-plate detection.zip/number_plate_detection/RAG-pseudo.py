from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import CharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_groq import ChatGroq
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()
groq_api_key = os.getenv("GROQ_API_KEY")
print("🔐 GROQ API Key Loaded:", bool(groq_api_key))

def rag_pipeline(query):
    # 1. Load Documents
    print("📄 Loading PDF document...")
    if not os.path.exists("License_Plates.pdf"):
        raise FileNotFoundError("License_Plates.pdf not found.")
    loader = PyPDFLoader("License_Plates.pdf")
    documents = loader.load()
    for i, doc in enumerate(documents):
        doc.metadata["source"] = f"Page {i+1}"
    print(f"✅ Loaded {len(documents)} document(s).")

    # 2. Split Text
    print("✂️ Splitting text into chunks...")
    text_splitter = CharacterTextSplitter(separator="\n", chunk_size=500, chunk_overlap=50)
    chunks = text_splitter.split_documents(documents)
    print(f"✅ Created {len(chunks)} text chunks.")

    # 3. Embeddings
    print("🧠 Creating HuggingFace embeddings...")
    embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")

    # 4. Vector Store (with caching)
    index_path = "faiss_index"
    if os.path.exists(index_path):
        print("📦 Loading existing FAISS index...")
        vectorstore = FAISS.load_local(index_path, embeddings)
    else:
        print("📦 Creating new FAISS vector store...")
        vectorstore = FAISS.from_documents(chunks, embeddings)
        vectorstore.save_local(index_path)
    print("✅ FAISS vector store ready.")

    # 5. Retrieval (using MMR for diversity)
    print("🔍 Retrieving relevant documents...")
    retriever = vectorstore.as_retriever(search_type="mmr", search_kwargs={"k": 5})
    retrieved_docs = retriever.invoke(query)
    print(f"✅ Retrieved {len(retrieved_docs)} relevant document(s).")

    if not retrieved_docs:
        print("⚠️ No relevant documents found. Try a different query.")
        return "No relevant information found."

    # 6. Generation using Groq
    print("🤖 Generating answer using Groq LLM...")
    llm = ChatGroq(model_name="llama3-70b-8192")
    context = "\n".join([doc.page_content for doc in retrieved_docs])
    prompt = f"""You are an expert assistant. Use the following context to answer the question accurately and concisely.

Context:
{context}

Question: {query}

Answer:"""
    answer = llm.invoke(prompt)
    print("✅ Answer generated.")
    return getattr(answer, "content", answer)

# Run the pipeline
question = "Which are the cars starting with the letter DL?"
print(f"\n🔍 Question: {question}")
answer = rag_pipeline(question)
print(f"\n📝 Answer: {answer}")
